<?php
/**
 * Intermediate template for search. Calls index.php template.
 * @package themify
 * @since 1.0.0
 */
?>
<?php get_template_part( 'index','search'); ?>